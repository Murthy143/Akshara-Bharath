<?php
/**
 * @file
 * This file contains markup for the dynamic views block.
 *
 * This views block used in the content admin tree
 * pages.
 */
?>
<div class="cat-views-block"><?php print $views_block ?></div>
