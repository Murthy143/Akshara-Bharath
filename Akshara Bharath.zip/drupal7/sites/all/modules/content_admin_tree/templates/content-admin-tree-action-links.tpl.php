<?php
/**
 * @file
 * File to add the markup to the content admin tree specific action links.
 */
?>
<ul class="action-links">
  <li>
    <a href="<?php print $action_path ?>"><?php print $action_title ?></a>
  </li>
</ul>
