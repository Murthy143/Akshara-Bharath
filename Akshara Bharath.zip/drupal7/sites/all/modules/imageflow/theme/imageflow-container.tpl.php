<?php
/**
 * @file
 * Displays a rendered output of imageflow images.
 */
?>
<div class="imageflow clearfix" id="imageflow-<?php print $id; ?>">
  <?php print render($imageflow); ?>
</div>
