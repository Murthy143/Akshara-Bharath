ImageFlow
======================
Installation:
Download the ImageFlow plugin at:
http://finnrudolph.de/ImageFlow/Download
The library js file should be available at:
sites/[whatever]/libraries/imageflow/imageflow.js
Note the all lowercase "imageflow" directory.

Configure presets at admin/config/media/imageflow

The module works as a field formatter for images, media,
node_reference, and field_collection

It also has views support for image fields. Adding link fields to
your views makes custom link paths possible.

It also supports colorbox (regular and iframe).
